package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class Util {
	public static Properties pro;

	/** Read data from property files. */
	public Util()

	{
		try {
			File src = new File("./config.properties");
			FileInputStream fis = new FileInputStream(src);
			pro = new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println("Exception is :" + e);
		}
	}

	public static String getPropertFileData(String key) {
		return pro.getProperty(key);
	}
}
