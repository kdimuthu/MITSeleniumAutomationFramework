package Utility;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;

public class TestBase_Commands extends SeleniumTestBase {

	/** Wait for the explicit wait */
	private static WebDriverWait wait;

	/** The web driver. */
	public static WebDriver driver = null;

	/** The time out. */
	private static int timeOut = 1;

	/**
	 * Sets the driver.
	 *
	 * @param driver
	 *            the new web driver
	 */
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * Gets the driver.
	 *
	 * @return the driver
	 */
	public static WebDriver getDriver() {
		return driver;
	}

	/**
	 * Launch the application.
	 *
	 * @param url
	 *            the url
	 */
	public void Open(String url) {

		try {
			getDriver().navigate().to(url);
			logs.log(Status.INFO, "Opened the browser [" + url + "] successfully");
		} catch (Exception e) {
			logs.log(Status.ERROR,
					MarkupHelper.createLabel("Fail to open the brower due to " + e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Type on a web element.
	 *
	 * @param byLocator
	 *            the by locator
	 * @param text
	 *            the text
	 */

	public void Type(By byLocator, String text) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			WebElement element = getDriver().findElement(byLocator);
			element.sendKeys(text);
			logs.log(Status.INFO, "Clicked on the object " + byLocator);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Click on a web element.
	 *
	 * @param byLocator
	 *            the by locator
	 */

	public void Click(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			WebElement element = getDriver().findElement(byLocator);
			element.click();
			logs.log(Status.INFO, "Clicked on the object " + byLocator);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify a massage
	 *
	 * @param byLocator
	 *            the by locator
	 * 
	 * @param expectedMessage
	 *            the expectedMessage
	 */
	public void VerifyText(By byLocator, String expectedMessage) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			String ActualtMessage = getDriver().findElement(byLocator).getText().replaceAll("\\s+", "");
			String ExpectedMessage = expectedMessage;
			if (ActualtMessage.equals(ExpectedMessage)) {
				logs.log(Status.INFO, "Verification done. Actual & Expected are same");
			} else {
				logs.log(Status.ERROR, MarkupHelper.createLabel(
						"Verification Fail. Expected (" + ExpectedMessage + ") but found (" + ActualtMessage + ")",
						ExtentColor.RED));

			}
			Assert.assertEquals(ActualtMessage, ExpectedMessage);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify a title
	 *
	 * @param title
	 *            the title
	 * 
	 */

	public void VerifyTitle(String title) {

		try {
			getDriver().manage().timeouts().implicitlyWait(timeOut, TimeUnit.SECONDS);
			String actualtTitle = getDriver().getTitle();
			String expectedTitle = title;
			if (actualtTitle.equals(expectedTitle)) {
				logs.log(Status.INFO, "Title Verification done. Actual & Expected titles are same");
			} else {
				logs.log(Status.ERROR,
						"Verification Fail. Expected (" + expectedTitle + ") but found (" + actualtTitle + ")");
			}
			Assert.assertEquals(actualtTitle, expectedTitle);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Get the status of element present
	 *
	 * @param byLocator
	 *            byLocator
	 * 
	 */

	public Boolean IsElementPresent(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Boolean elementStatus = getDriver().findElement(byLocator).isDisplayed();
			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Object " + byLocator + " Exists in the page");
			}
			return elementStatus;
		} catch (Exception e) {
			logs.log(Status.ERROR,
					MarkupHelper.createLabel(
							"Object " + byLocator + " doesn't exist in the page & throws the below exception",
							ExtentColor.RED));
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the element is presented
	 *
	 * @param byLocator
	 *            byLocator
	 * 
	 */

	public void CheckElementPresent(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Boolean elementStatus = getDriver().findElement(byLocator).isDisplayed();
			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Object " + byLocator + " Exists in the page");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR,
					MarkupHelper.createLabel(
							"Object " + byLocator + " doesn't exist in the page & throws the below exception",
							ExtentColor.RED));
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the element is enabled
	 * 
	 * @param byLocator
	 *            byLocator
	 * 
	 */
	public void CheckElementEnabled(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Boolean elementStatus = getDriver().findElement(byLocator).isEnabled();
			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Object " + byLocator + " Enabled in the page");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR,
					MarkupHelper.createLabel(
							"Object " + byLocator + " doesn't enabled in the page & throws the below exception",
							ExtentColor.RED));
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the element is selected
	 * 
	 * @param byLocator
	 *            byLocator
	 * 
	 */
	public void CheckElementSelected(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Boolean elementStatus = getDriver().findElement(byLocator).isSelected();
			if (elementStatus.equals(true)) {
				logs.log(Status.INFO, "Object " + byLocator + " Enabled in the page");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR,
					MarkupHelper.createLabel(
							"Object " + byLocator + " doesn't enabled in the page & throws the below exception",
							ExtentColor.RED));
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify the property of an element
	 * 
	 * @param byLocator
	 *            byLocator
	 * @param properyType
	 *            properyType
	 * @param propertyValue
	 *            propertyValue
	 */
	public void VerifyElementProperty(By byLocator, String properyType, String propertyValue) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			String ActualtProperty = getDriver().findElement(byLocator).getAttribute(properyType);
			String ExpectedProperty = propertyValue;
			if (ActualtProperty.equals(ExpectedProperty)) {
				logs.log(Status.INFO, "Verification done. Actual & Expected are same");
			} else {
				logs.log(Status.ERROR, MarkupHelper.createLabel(
						"Verification Fail. Expected (" + ExpectedProperty + ") but found (" + ActualtProperty + ")",
						ExtentColor.RED));

			}
			Assert.assertEquals(ActualtProperty, ExpectedProperty);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}

	}

	/**
	 * Verify the property of an element
	 * 
	 * @param byLocator
	 *            byLocator
	 * @param selectType
	 *            selectType
	 * @param value
	 *            value
	 */

	public void SelectValueFromDrowDown(By byLocator, String selectType, String value) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));

			if (selectType.equals("selectByVisibleText")) {
				ddValue.selectByVisibleText(value);
			} else if (selectType.equals("SelectByIndex")) {
				ddValue.selectByIndex(Integer.parseInt(value));
			} else if (selectType.equals("SelectByValue")) {
				ddValue.selectByValue(value);
			}

			logs.log(Status.INFO, "Selected the option " + value + " from the dropdown " + byLocator);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Clear a element on a text
	 *
	 * @param byLocator
	 *            the by locator
	 */

	public void Clear(By byLocator) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			WebElement element = getDriver().findElement(byLocator);
			element.clear();
			logs.log(Status.INFO, "Cleare the text on the object " + byLocator);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store message to a variable
	 *
	 * @param byLocator
	 *            the by locator
	 */

	public String StoreText(By byLocator) {
		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}

			String elementText = getDriver().findElement(byLocator).getText();
			if (elementText != null && !elementText.isEmpty()) {
				logs.log(Status.INFO,
						"Stored the text message of object " + byLocator + "& Stored text is [" + elementText + "]");
			} else {
				logs.log(Status.INFO, "NO text is availale for the " + byLocator + " object");
			}

			return elementText;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}

	}

	/**
	 * Store message to a variable
	 *
	 * @param byLocator
	 *            the by locator
	 * @param propertyType
	 *            the property Type
	 */

	public String StoreProperty(By byLocator, String propertyType) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}

			String elementProperty = getDriver().findElement(byLocator).getAttribute(propertyType);
			if (elementProperty != null && !elementProperty.isEmpty()) {
				logs.log(Status.INFO, "Stored the Property [" + propertyType + "] of the object" + byLocator
						+ " & Stored property is [" + elementProperty + "]");
			} else {
				logs.log(Status.INFO, "NO Property value is availale for the property [" + propertyType + "] for the"
						+ byLocator + " object");
			}

			return elementProperty;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Store message to a variable
	 *
	 * @param byLocator
	 *            the by locator
	 */
	public int getCount(By byLocator) {
		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}

			int itemCount = getDriver().findElements(byLocator).size();
			if (itemCount > 0) {
				logs.log(Status.INFO, "Item count for the object " + byLocator + " is [" + itemCount + "]");
			} else {
				logs.log(Status.INFO, "NO Items are availebl for the " + byLocator + " object");
			}

			return itemCount;

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify selected option in a drop down
	 *
	 * @param byLocator
	 *            the by locator
	 * @param expectedOption
	 *            the expected Option
	 */
	public void VerifySelectedOption(By byLocator, String expectedOption) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Select ddValue = new Select(getDriver().findElement(byLocator));
			String selectedOption = ddValue.getFirstSelectedOption().getText().replaceAll("\\s+", "");
			String _expectedOption = expectedOption;
			if (selectedOption.equals(_expectedOption)) {
				logs.log(Status.INFO, "Default option display correctly as [" + selectedOption + "].");
			} else {
				logs.log(Status.INFO,
						"Expected default option is [" + _expectedOption + "]. But found [" + selectedOption + "]");
			}
			Assert.assertEquals(selectedOption, _expectedOption);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Verify all the option in a drop down
	 *
	 * @param byMainLink
	 *            the by main link to be clicked
	 * @param bySubLink
	 *            the by sub link to be clicked
	 */

	public void CheckOptions(By byLocator) {
		wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
		String[] expectedValues = { "No Preference", "Blue Skies Airlines", "Unified Airlines", "df" };
		Select ddValue = new Select(getDriver().findElement(byLocator));
		List<WebElement> dropdownList = ddValue.getOptions();
		for (int i = 0; i < dropdownList.size(); i++) {
			if (expectedValues[i].equals(dropdownList.get(i).getText())) {
				logs.log(Status.INFO, "Options" + expectedValues[i] + "display correctly");
			} else {
				logs.log(Status.INFO,
						"Expected [" + expectedValues[i] + "]. But found " + dropdownList.get(i).getText());
			}
			Assert.assertEquals(expectedValues[i], dropdownList.get(i).getText());
		}
	}

	/**
	 * Mouse hover & click
	 *
	 * @param byMainLink
	 *            the by main link to be clicked
	 * @param bySubLink
	 *            the by sub link to be clicked
	 */
	public void MouseHoverAndClick(By byMainLink, By bySubLink) {

		try {
			try {
				wait = new WebDriverWait(getDriver(), timeOut);
				wait.until(ExpectedConditions.presenceOfElementLocated(byMainLink));
			} catch (TimeoutException e) {
				logs.log(Status.WARNING, MarkupHelper.createLabel(e.getMessage(), ExtentColor.AMBER));
			}
			Actions builder = new Actions(driver);
			builder.moveToElement(getDriver().findElement(byMainLink)).perform();
			getDriver().findElement(bySubLink).click();
			logs.log(Status.INFO,
					"Mouse hover the object [" + byMainLink + "] & Click on the [" + bySubLink + "] link");
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
			throw e;
		}
	}

	/**
	 * Navigates back
	 */
	public void NavigateBack() {

		try {
			getDriver().navigate().back();
			logs.log(Status.INFO, "Navigated to previous screen");
		} catch (TimeoutException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Navigates back
	 */
	public void NavigateForward() {

		try {
			getDriver().navigate().forward();
			;
			logs.log(Status.INFO, "Navigated to next screen");
		} catch (TimeoutException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Navigates to given url
	 * 
	 * @param url
	 *            the url to be navigated
	 */
	public void NavigateToURL(String url) {

		try {
			getDriver().navigate().to(url);
			logs.log(Status.INFO, "Navigated to the URL" + url + "successfully");
		} catch (TimeoutException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Explicit Wait
	 *
	 * @param byLocator
	 *            the by Locator
	 * @param time
	 *            the time
	 */
	public void WaitForElementPresent(By byLocator, int time) {
		try {
			wait = new WebDriverWait(getDriver(), time);
			wait.until(ExpectedConditions.presenceOfElementLocated(byLocator));
			logs.log(Status.INFO, "Waited [" + time + "] seconds till page or element is loaded");
		} catch (TimeoutException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Implicit Wait
	 * 
	 * @param time
	 *            the time
	 */
	public void Wait(int time) {

		getDriver().manage().timeouts().implicitlyWait(time, TimeUnit.SECONDS);
		logs.log(Status.INFO, "Waited [" + time + "] seconds till page or element is loaded");

	}

	/**
	 * Tread Sleep
	 * 
	 * @param time
	 *            the time
	 */
	public void Sleep(int time) {

		try {
			Thread.sleep(time);
			logs.log(Status.INFO, "Waited [" + time + "] seconds till page or element is loaded");
		} catch (InterruptedException e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Press keyboard keys
	 * 
	 * @param time
	 *            the time
	 */
	public void PreseKey(String KeyLable) {

		try {
			Robot _Robot = new Robot();
			switch (KeyLable.toUpperCase()) {
			case "Enter":
				_Robot.keyPress(KeyEvent.VK_ENTER);
				_Robot.keyRelease(KeyEvent.VK_ENTER);
				break;

			case "Tab":
				_Robot.keyPress(KeyEvent.VK_TAB);
				_Robot.keyRelease(KeyEvent.VK_TAB);
				break;

			case "PageUp":
				_Robot.keyPress(KeyEvent.VK_PAGE_UP);
				_Robot.keyRelease(KeyEvent.VK_PAGE_UP);
				break;

			case "PageDown":
				_Robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				_Robot.keyRelease(KeyEvent.VK_PAGE_DOWN);
				logs.log(Status.INFO, "Press the key [" + KeyLable + "] from the keyboard.");
				break;
			default:
				logs.log(Status.INFO, "Undefined key is entered");
			}

		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

	/**
	 * Write something on the report.
	 *
	 * @param message
	 *            the message to be written
	 */
	public void WriteToReport(String message) {

		try {
			logs.log(Status.INFO, message);
		} catch (Exception e) {
			logs.log(Status.ERROR, MarkupHelper.createLabel(e.getMessage(), ExtentColor.RED));
		}
	}

}
