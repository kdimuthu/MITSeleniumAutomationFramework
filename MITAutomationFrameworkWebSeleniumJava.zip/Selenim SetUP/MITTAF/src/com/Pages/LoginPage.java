package com.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Utility.TestBase_Commands;

public class LoginPage extends TestBase_Commands {
	private static By tf_UserName = By.xpath("//input[@name='userName']");
	private static By tf_Password = By.xpath("//input[@name='password']");
	private static By btn_Login = By.xpath("//input[@name='login']");
	private static By lbl_UserName = By.xpath("//font[contains(text(),'User')]");
	private static By tf_UserName1 = By.id("//input[@name='userName']");
	private static By dd_Airline = By.xpath("//select[@name='airline']");

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// login to application
	public void bf_Login(String prm_userName, String prm_password) {
		Open("http://www.newtours.demoaut.com/");
		Type(tf_UserName, prm_userName);
		// Clear(tf_UserName);
		// Type(tf_UserName, prm_userName);
		Type(tf_Password, prm_password);
		// StoreText(lbl_UserName);
		// StoreProperty(btn_Login, "value");
		IsElementPresent(lbl_UserName);
		// CheckElementPresent(lbl_UserName);
		// VerifyElementProperty(btn_Login, "value", "Login1");
		// VerifyText(lbl_UserName, "UserName:");
		// String element=StoreText(lbl_UserName);
		// WriteToReport("Stored Text is "+element);
		// PreseKey("Enter");
		Click(btn_Login);
		// CheckOptions(dd_Airline);
		// VerifySelectedOption(dd_Airline, "NoPreference");
		// SelectValueFromDrowDown(dd_Airline,"selectByVisibleText","Blue Skies
		// Airlines");
		// VefirySelectedValue(dd_Airline, "1");
		// CheckElementPresent(dd_Airline);

	}

}
