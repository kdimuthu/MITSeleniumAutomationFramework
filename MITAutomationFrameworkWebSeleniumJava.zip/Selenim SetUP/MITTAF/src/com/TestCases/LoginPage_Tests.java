package com.TestCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.Pages.LoginPage;
import Utility.ExcelReader;
import Utility.SeleniumTestBase;

public class LoginPage_Tests extends SeleniumTestBase {
	LoginPage _LoginPage;

	@Test(priority = 1, enabled = true)
	public void tc_Verifylogin() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_Login(ExcelReader.getData(0, 1, 0), ExcelReader.getData(0, 1, 1));
		Assert.assertEquals("3", "4");
		// logs.log(Status.INFO, "Executed in Chrome browser");
	}

	@Test(priority = 2, enabled = true)
	public void tc_VerifyTitle() {
		_LoginPage = new LoginPage(driver);
		_LoginPage.bf_Login(ExcelReader.getData(0, 1, 0), ExcelReader.getData(0, 1, 1));
		// Assert.assertEquals("2", "22");
	}
}
